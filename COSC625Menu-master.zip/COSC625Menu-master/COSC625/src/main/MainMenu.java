package main;

import DataFunctions.*;
import project.RAPMenu;

public class MainMenu {

	public static void main(String[] args) {
		new AddTables();
		new DataSource();
		new CSVImport();
		new RAPMenu();
	}

}
