package MenuFunctions;

import project.RAPMenu;

public class SuggestClasses {

	public SuggestClasses(RAPMenu rp1) {
		rp1.getMainPanel().removeAll();
		rp1.getMainLabel().setText("Success! Class: SuggestClasses works!");
//		return suggest;
	}

}
