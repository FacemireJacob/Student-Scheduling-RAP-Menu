package MenuFunctions;

import project.RAPMenu;

public class ViewSections {

	public ViewSections(RAPMenu rp1) {
		rp1.getMainPanel().removeAll();
		rp1.getMainLabel().setText("Success! View Sections works!");
	}

}
